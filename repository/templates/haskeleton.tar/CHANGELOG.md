# Change log

This package uses [Semantic Versioning][1].

## v0.0.0

-   Initially created.

[1]: http://semver.org/spec/v2.0.0.html
