module Setup (main) where

import Distribution.Simple (defaultMain)

main :: IO ()
main = defaultMain
